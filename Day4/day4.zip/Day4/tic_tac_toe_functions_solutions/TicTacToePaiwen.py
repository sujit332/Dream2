# part 2
def display(ttt):
   for i in range(3):
       print(ttt[i])

def tic_tac_toe_start():
   ttt = []
   for i in range(3):
       t = []
       for j in range(3):
           t.append(tuple([i, j]))
       ttt.append(t)
   return ttt

def check_winner(ttt, sym):
   if all(val == sym for val in [ttt[0][0], ttt[0][1], ttt[0][2]]) or \
      all(val == sym for val in [ttt[1][0], ttt[1][1], ttt[1][2]]) or \
      all(val == sym for val in [ttt[2][0], ttt[2][1], ttt[2][2]]) or \
      all(val == sym for val in [ttt[0][0], ttt[1][0], ttt[2][0]]) or \
      all(val == sym for val in [ttt[0][1], ttt[1][1], ttt[2][1]]) or \
      all(val == sym for val in [ttt[0][2], ttt[1][2], ttt[2][2]]) or \
      all(val == sym for val in [ttt[0][0], ttt[1][1], ttt[2][2]]) or \
      all(val == sym for val in [ttt[0][2], ttt[1][1], ttt[2][0]]):
       return True
   else:
       return False

def check_winner2(ttt, sym):
   found = False
   ## cover 3 scenarios - 3 same symbols on the same row
   for l in ttt:
       if all(val == sym for val in l):
           found = True
   ## check 3 scenarios - 3 same symbols on the same column
   for i in range(3):
       if all(val == sym for val in [ttt[0][i],ttt[1][i],ttt[2][i]]):
           found = True
   ## check 3 scenarios - 3 same symbols on diagonal position
   if all(val == sym  for val in [ttt[0][0], ttt[1][1], ttt[2][2]]) or \
      all(val == sym for val in [ttt[0][2],ttt[1][1],ttt[2][0]]):
       found = True
   return found

# part 4
def accept_a_play():
   ttt = tic_tac_toe_start()
   display(ttt)
   p = []
   winner = False
   turn = 0
   full_count = 0
   while not winner:
       player = turn % 2 + 1
       p = input('Player ' + str(player) + ', where will you play? ').split(',')
       if len(p[0]) == 0:
           print('Game stops!')
           break
       pos = tuple([int(p[0]), int(p[1])])
       for l in ttt:
           ind = l.index(pos) if pos in l else -1
           if ind >= 0 and l[ind] != 'X' and l[ind] != 'O':
               if player == 1:
                   symbol = 'X'
               else:
                   symbol = 'O'
               l[ind] = symbol
               full_count+=1
               display(ttt)
               if (check_winner(ttt, symbol)):
                   print('Congratulation! Player ' + str(player) + ' is the winner!')
                   return
       turn += 1
       if full_count == 9:
           print('Tie game!')
           return
   return

accept_a_play()