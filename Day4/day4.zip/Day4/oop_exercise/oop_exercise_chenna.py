class Circle:
  def __init__(self,radius):
      self.raduis=radius
  def circle_area(self):
      #print(22/7)
      self.area=(22/7)*(self.raduis**2)
      return self.area
c1 = Circle(4)
print(c1.circle_area())

class Rectangle:
  def __init__(self,length, width):
      self.length=length
      self.width=width
  def rect_area(self):
      self.area=self.length*self.width
      return self.area
r1 = Rectangle(3,4)
print(r1.rect_area())

class Person:
  def __init__(self,name):
      self.name=name
     
  def legally_change_name(self,new_name):
      self.name=new_name
     
  def introduce_myself(self):
      print("My name is {} ".format(self.name))
 
 
 
p1= Person("Chenna")
p1.legally_change_name("Chenna Panthagani")
p1.introduce_myself()
p2= Person("Kesava")
p2.legally_change_name("Kesava Rao")
p2.introduce_myself()