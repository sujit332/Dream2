import math
class Circle:

    def __init__(self, radius): 
        self.radius=radius

    def AreaOfCircle(self):
        area = float(math.pi*(self.radius **2))
        return area

class Rectangle:
 
    def __init__(self, length, width):
        self.length=length
        self.width=width

    def AreaOfRectangle(self):
        area = float(self.length * self.width)
        return area

class Person:
 
    def __init__(self, name):
        self.name = name 

    def introduce_myself(self):
        print("My name is {}".format(self.name))

    def legally_name_change(self, name):
        self.name=name
        print("The name has been changed to {}".format(self.name))


if __name__ == '__main__':

    r=Rectangle(10, 12)
    print(r.AreaOfRectangle())

    c=Circle(10)
    print(c.AreaOfCircle())

    p1=Person("Martin")
    p1.introduce_myself()
    p1.legally_name_change("Tintin")

    p2=Person("Sam")
    p2.introduce_myself()
    p2.legally_name_change("Sampras")
    p2.introduce_myself()
