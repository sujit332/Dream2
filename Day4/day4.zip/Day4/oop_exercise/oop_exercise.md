1. Define a class named Circle which can be constructed by a radius. The Circle class has a method which can compute the area.

2. Define a class named Rectangle which can be constructed by a length and width. The Rectangle class has a method which can compute the area.

3. Write a class Person
    - Have this class have state: name
    - have this class have action: legally_change_name()
    - Have this class have action: introduce_myself()
   Create two poeple and have them introduce themselves. Change one of their names. Have them introduce themselves again. 