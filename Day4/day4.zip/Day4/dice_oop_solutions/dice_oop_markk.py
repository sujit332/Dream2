# Nouns: bag, dice, game
# Verbs: roll, draw, sum

import random

class Die:
    def __init__(self, num_sides):
        if num_sides > 20:
            raise ValueError("You can't have more than a 20 sided die!")
        if num_sides % 2 != 0:
            raise ValueError("You can't have an odd-sided die")
        self._num_sides = num_sides

    def roll(self):
        return random.randint(1, self._num_sides)

    def num_sides(self):
        return self._num_sides

class Bag:
    _dicebag = []
    _no_of_dice = 0

    def __init__(self, dice_config):
        #setup dice bag
        for sides,num_dice in dice_config.items():
            #create x no. of dice
            for i in range(0,num_dice):
                d = Die(sides)
                self._dicebag.append(d)
                self._no_of_dice +=1

    def draw(self, num_things):
        dice_drawn = []
        random.shuffle(self._dicebag)
        for i in range(0,num_things):
            dice_drawn.append(self._dicebag.pop())
        return dice_drawn

    def is_valid(self,dice_to_discard, dice_to_roll):
        if dice_to_roll <= 0 :
            print ("you can't play this game with no dice")
            return False
        elif dice_to_roll > self._no_of_dice - dice_to_discard:
            print("you can't play this game, you do not have enough dice left to roll")
            return False
        elif self._no_of_dice < dice_to_discard + dice_to_roll:
            print ("you can't play this game with no dice")
            return False
        else:
            return True

    def playgame(self, dice_to_discard, dice_to_roll):
        if self.is_valid(dice_to_discard, dice_to_roll)==False:
            return
        #play the game
        print("There are {} dice in total in the dice bag".format(self._no_of_dice))
        set_aside = b.draw(num_things=dice_to_discard)
        print ("The following {} dice have been discarded : {}".format(dice_to_discard,[d.num_sides() for d in set_aside]))
        drawn = b.draw(num_things=dice_to_roll)
        print("The following {} dice have been drawn : {}".format(dice_to_roll,[d.num_sides() for d in drawn]))
        s = sum([die.roll() for die in drawn])
        print("The sum of the {} rolled dice is : {}".format(dice_to_roll,s))

if __name__ == '__main__':
    b = Bag({4:1, 6:2, 8:4, 10:2, 12:1, 20:3})
    b.playgame(dice_to_discard=3,dice_to_roll=2)


#It has: 1d4, 2d6, 4d8, 2d10, 1d12, 3d20. 