import random

class Die:
    def __init__(self, num_sides):
        if num_sides > 20:
            raise ValueError("You can't have more than a 20 sided die!")
        if num_sides % 2 != 0:
            raise ValueError("You can't have an odd-sided die")
        self._num_sides = num_sides 
        
    def set_sides(self, sides):
        self._num_sides = sides 
        
    def roll(self):
        return random.randint(1, self._num_sides)

class Bag:
    def __init__(self, dice_dict):
        self._dice_dict = dice_dict
        self._dice_to_return = []
        
    def draw(self, num_things, hold_or_roll = 'hold'):
        self._die_num = 0
        self._dice_to_return = []
        
        for i in range(num_things):
            #print(i)
            print('Bag contents: {}'.format(self._dice_dict))
            self._die_num = random.choice(list(self._dice_dict))
            if hold_or_roll == 'hold':
                print('Held die: {}'.format(self._die_num))
            else:                
                print('Rolled die: {}'.format(self._die_num))
            self._dice_dict[self._die_num] -= 1
            if self._dice_dict[self._die_num] == 0:
                del self._dice_dict[self._die_num]
            self._dice_to_return.append(Die(self._die_num))            
        
        return self._dice_to_return

if __name__ == '__main__':
    b = Bag({4:1, 6:2, 8:4, 10:3, 12:1, 20:3})
    set_aside = b.draw(num_things=3,hold_or_roll='hold')
    drawn = b.draw(num_things=2,hold_or_roll='roll')
    #print(drawn)
    s = sum([die.roll() for die in drawn])
    print(s)


#It has: 1d4, 2d6, 4d8, 2d10, 1d12, 3d20. 