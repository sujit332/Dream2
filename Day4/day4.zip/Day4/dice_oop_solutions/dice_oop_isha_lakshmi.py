# Verbs: roll, draw, sum

import random

class Die:
   def __init__(self, num_sides):
       if num_sides > 20:
           raise ValueError("You can't have more than a 20 sided die!")
       if num_sides % 2 != 0:
           raise ValueError("You can't have an odd-sided die")
       self._num_sides = num_sides

   def roll(self):
       dice_rolled= random.randint(1, self._num_sides)
       print('Die {} rolled {}'.format(self._num_sides,dice_rolled))
       return dice_rolled
   
   def get_num_sides(self):
       return self._num_sides
   
   def __str__(self):
       return 'Die {}'.format(self.get_num_sides())
   
   

class Bag:
   def __init__(self,dice_dict):
       self.diceList=[]
       for num_sides,count in dice_dict.items():
           for i in range(count):
               self.diceList.append(Die(num_sides))
       
   def draw(self,num_things):
       drawn=[]
       for i in range(num_things):
           random.shuffle(self.diceList)
           drawn.append(self.diceList.pop())
       return drawn


if __name__ == '__main__':
   b = Bag({4:1, 6:2, 8:4, 10:2, 12:1, 20:3})
   set_aside = b.draw(num_things=3)
   
   print('Dice set aside ')
   for dice in set_aside:
       print(dice)
   
   print('Dice picked to roll ')
   drawn = b.draw(num_things=2)
   for dice in drawn:
       print(dice)
   print(sum([die.roll() for die in drawn]))