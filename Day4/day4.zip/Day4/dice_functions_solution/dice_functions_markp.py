import random

def pick_die_from_bag(bag=[1,2,3]):
    x = int(len(bag) * random.random())
    die = bag[x]
    del bag[x]
    return die, bag

bag=[4,6,6,8,8,8,8,10,10,12,20,20,20]
print(bag)
for i in range(3):
    removeddie, bag = pick_die_from_bag(bag)
    print('removed {}, bag is now {}'.format(removeddie,bag))
die1, bag =pick_die_from_bag(bag)
die2, bag =pick_die_from_bag(bag)
print('the dice {} {} :'.format(die1,die2))
roll1=int(die1*random.random()+1)
roll2=int(die2*random.random()+1)

print('the rolls {a} {b} : total {c}'.format(a=roll1, b=roll2, c=roll1+ roll2))