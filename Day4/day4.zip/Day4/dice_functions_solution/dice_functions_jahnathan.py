import random

dice_bag = [4,6,6,8,8,8,8,10,10,12,20,20,20]
roll_sum = 0
used_dice = []

for x in range(5):
  # Choose one of the 13 dice
  dice_num = -1
  while dice_num in used_dice or dice_num == -1:
    dice_num = random.randint(0,13)

  used_dice.append(dice_num)
  # skip 3
  if x >= 3: 
    print("Die number {0} has {1} sides.".format(x+1, dice_bag[dice_num]))
    # Roll die
    dice_roll = random.randint(1,dice_bag[dice_num])
    print("Dice roll number {0} was {1}.\r\n".format(x+1, dice_roll))
    # Add roll to sum
    roll_sum += dice_roll
  else:
    print("Skipped die number {0} has {1} sides.\r\n".format(dice_num, dice_bag[dice_num]))

print("The sum of the rolls was {0}.".format(roll_sum))
print("Selected dice indexes were {0}.".format(used_dice))