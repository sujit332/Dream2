import random

dice = [4, 6, 6, 8, 8, 8, 8, 10, 10, 12, 20, 20, 20]
print(dice)
print('Shuffling...')
random.shuffle(dice)
print(dice)

#remove 3 die
pick = random.sample(dice,3)
print('Remove the following sided die:')
for i in pick:
   print(i)
   dice.remove(i)
   
print('Dice left:')
print(dice)

roll = random.sample(dice, 2)
print('Remove the following sided die to roll:')
print(roll)

total=0
for i in roll:
   print(i)
   die_value = random.randint(1, i)
   print('Sided die {} rolled a: {}'.format(i, die_value))
   total += die_value

print('I rolled a {}'.format(total))