import random
def play_game():
    lst = [4,6,6,8,8,8,8,10,10,12,20,20,20]
    print("We have: {}".format(lst))
    dice1, dice2 = 0,0

    random.shuffle(lst)
    for i in range(0,3):
        print("Pop: {}".format(lst.pop()))
        
    print("What left: {}".format(lst))
    random.shuffle(lst)
    dice1 = lst.pop()
    print("Pull: {}".format(dice1))
    dice2 = lst.pop()
    print("Pull: {}".format(dice2))

    rand1 = random.randint(1, dice1)
    rand2 = random.randint(1, dice2)
    print("Sum up: {} + {} = {}".format(rand1, rand2, rand1+rand2))