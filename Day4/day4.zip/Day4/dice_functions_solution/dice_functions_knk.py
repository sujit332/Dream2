import random as rd

dice = [(1,4),(2,6),(4,8),(2,10),(1,12),(3,20)]
dice_list = []
for (number, sides) in dice:
    for _ in range(number):
        dice_list.append(sides)

print ("Before")
print (dice_list)
        
for i in range(3):
    dice_list.remove(random.choice(dice_list))

print ("After")
print (dice_list)
    
first = random.choice(dice_list)
dice_list.remove(first)
print ("First dice has {} sides".format(first))
second = random.choice(dice_list)
print ("Second dice has {} sides".format(second))
dice_list.remove(second)


print (random.randint(1,first)+ random.randint(1,second))